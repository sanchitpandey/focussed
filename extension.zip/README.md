# Focussed.

This is a robust and handy chrome extension which can greatly improve your productivity and bring you one step closer towards your goals!

## Features

1) It intercepts the new tab page and shows you another screen
2) This screen will have constantly changing backgrounds and quotes
3) It will show time and allow google search
4) It will also allow you to add tasks and check them off
5) Live Weather updates

## Stack

1) HTML
2) CSS
3) JavaScript
4) Bootstrap 4

